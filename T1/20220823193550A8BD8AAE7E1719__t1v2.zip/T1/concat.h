typedef unsigned int uint;
uint concat_bits(uint x, int n, uint y, int m);

