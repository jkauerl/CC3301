#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "concat.h"

uint concat_bits(uint x, int n, uint y, int m) {
// Ejemplo:: concat_bits(101, 3, 11001, 5)
//  retorna 10111001
// 
// 
    unsigned i = -1;
    unsigned mask1 = ~(i<<n); // mask de x
    unsigned mask2 = ~(i<<m); // mask de y

    mask1 = mask1 << m;
    x <<= m;

    x &= mask1;
    y &= mask2;
    x |= y;

    return x;
}

