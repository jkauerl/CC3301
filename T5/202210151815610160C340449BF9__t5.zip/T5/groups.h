int groups(unsigned int x);
