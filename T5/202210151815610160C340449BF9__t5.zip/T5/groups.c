#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "groups.h"

int groups(unsigned int x) {
  // Programe aca la funcion groups
  return 0;
}
