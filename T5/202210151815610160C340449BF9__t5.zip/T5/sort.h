typedef unsigned int uint;
void sort(uint nums[], int n);
